---
name: Cyber-Forensics Telemetry
colors:
  surface: '#0f141b'
  surface-dim: '#0f141b'
  surface-bright: '#353941'
  surface-container-lowest: '#0a0e15'
  surface-container-low: '#181c23'
  surface-container: '#1c2027'
  surface-container-high: '#262a32'
  surface-container-highest: '#31353d'
  on-surface: '#dfe2ed'
  on-surface-variant: '#e1bebf'
  inverse-surface: '#dfe2ed'
  inverse-on-surface: '#2c3139'
  outline: '#a8898a'
  outline-variant: '#594041'
  surface-tint: '#ffb3b6'
  primary: '#ffb3b6'
  on-primary: '#680019'
  primary-container: '#ff5b6e'
  on-primary-container: '#620017'
  inverse-primary: '#b4223c'
  secondary: '#9de32e'
  on-secondary: '#213600'
  secondary-container: '#83c600'
  on-secondary-container: '#314d00'
  tertiary: '#e1c700'
  on-tertiary: '#383000'
  tertiary-container: '#c2ac00'
  on-tertiary-container: '#494000'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdada'
  primary-fixed-dim: '#ffb3b6'
  on-primary-fixed: '#40000c'
  on-primary-fixed-variant: '#920027'
  secondary-fixed: '#b0f743'
  secondary-fixed-dim: '#95da23'
  on-secondary-fixed: '#111f00'
  on-secondary-fixed-variant: '#324f00'
  tertiary-fixed: '#ffe325'
  tertiary-fixed-dim: '#e1c700'
  on-tertiary-fixed: '#211c00'
  on-tertiary-fixed-variant: '#514700'
  background: '#0f141b'
  on-background: '#dfe2ed'
  surface-variant: '#31353d'
typography:
  headline-xl:
    fontFamily: Space Grotesk
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.03em
  headline-xl-mobile:
    fontFamily: Space Grotesk
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
    letterSpacing: 0em
  body-lg:
    fontFamily: Space Mono
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-md:
    fontFamily: Space Mono
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Space Mono
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: Space Mono
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.08em
  label-md:
    fontFamily: Space Mono
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.1em
  label-sm:
    fontFamily: Space Mono
    fontSize: 9px
    fontWeight: '700'
    lineHeight: 12px
    letterSpacing: 0.12em
spacing:
  gutter: 1rem
  gutter-sm: 0.5rem
  gutter-lg: 1.5rem
  margin: 1.5rem
  margin-sm: 1rem
  margin-lg: 2.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system establishes a high-precision, cyber-forensics environment calibrated for vulnerability research, agent sandbox evaluation, and threat replay analysis. The aesthetic synthesizes high-density technical telemetry with zero-radius machine brutality, rejecting soft ornamental visual cues in favor of crisp diagnostic transparency.

Targeted at adversarial security engineers, autonomous protocol auditors, and security research teams, the UI evokes an unvarnished terminal execution layer. Surfaces sit flush against structural grid lines, signaling deterministic finality, computational rigor, and immediate operational clarity. Data density is prioritized over negative space, presenting critical transaction signatures, payload streams, and injection state transitions without cosmetic abstraction.

## Colors

The palette operates under a high-contrast dark spectrum designed for rapid cognitive identification of exploit states, execution states, and telemetry data.

- **Primary (`#FF5B6E`)**: Threat-centric coral crimson. Anchors exploit detections, breached invariants, critical attack traces, and system compromise vectors.
- **Secondary (`#B7FF4A`)**: Electric lime green. Denotes invariant integrity, successful mitigation barriers, blocked payload signals, and live sandbox validation.
- **Tertiary (`#FEE101`)**: Acid amber. Highlights anomalous execution paths, parsing timeouts, simulated test faults, and trace irregularities.
- **Neutral Base (`#070B12`)**: Deep void canvas tone providing the bedrock for stacked diagnostic modules.
- **Sub-surfaces**: Tiered dark slates (`#0D1424` container, `#121B30` elevated/interactive container) segmented strictly by thin structural framing (`#1E2D4A`).
- **Typography & Status Neutral**: Warm ivory (`#FFFBE8`) dominates operational hierarchy, muted telemetric metadata resides in slate steel (`#8E9BAE`, `#5B6B82`), and inert evaluations fall back to neutral carbon (`#6B7280`).

## Typography

The typography couples structural architectural headers with disciplined, fixed-width telemetry body execution. 

- **Space Grotesk** serves structural views, module headers, metric banners, and high-impact verdict statements, injecting an angular, machine-milled presence into the interface.
- **Space Mono** handles all body content, parameter matrices, bytecode hex reads, prompt injections, and contextual metadata. It enforces strict column vertical alignment and reinforces the terminal environment.
- All labels and status verdicts utilize capitalized monospace treatments with positive tracking (`0.08em` to `0.12em`) to guarantee quick recognition under high-density audit situations.

## Layout & Spacing

The layout is built around a dense 12-column grid system optimized for technical workspaces and real-time event logs.

- **Desktop (1280px+)**: 12 columns, 16px (`1rem`) gutters, 40px (`2.5rem`) outer margins. Supports side-by-side terminal splits, live payload injection monitors, and timeline telemetry.
- **Tablet (768px - 1279px)**: 8 columns, 16px (`1rem`) gutters, 24px (`1.5rem`) margins. Secondary panels collapse into tabbed segments beneath the primary telemetry viewport.
- **Mobile (< 768px)**: 4 columns, 8px (`0.5rem`) gutters, 16px (`1rem`) margins. Strict linear flow; data density is preserved via horizontally scrollable byte tables and expandable inspection drawbars.

Components conform to an 8px base rhythm with 4px sub-increments (`space-xs`) for internal token tags, badge paddings, and hash-delimiter spacing. Structural seams are flush, relying on strict borders rather than expansive whitespace.

## Elevation & Depth

This design system avoids traditional drop shadows and blur filters, drawing instead from flat, hard-edged technical instrumentation:

- **Surface Tiers**: Base canvas runs `#070B12`. Inactive telemetry cards sit on `#0D1424`. Active execution frames, modal inspectors, and focused sandboxes raise to `#121B30`.
- **Low-Contrast Outlines & Seams**: Depth is rendered through 1px structural strokes using `#1E2D4A`. Cards appear welded together along shared boundaries.
- **Accent Highlighting**: Elevated interactive states use 1px hard inset/offset edges with high-contrast indicator values: `#FF5B6E` for exploit targets, `#B7FF4A` for operational locks, `#1E2D4A` for idle states.
- **Diagnostic Illumination**: High-priority alert states use zero-spread, directional 1px solid stroke flashes rather than diffuse ambient glows, maintaining absolute visual sharpness.

## Shapes

The design system enforces an uncompromising zero-radius rule (`0px`) across the entire visual language.

- Every boundary, frame, container, button, input field, and status pill features razor-sharp corners.
- Badges, modals, code blocks, and scroll trackers do not soften edges.
- Corners emphasize technical utility, reminiscent of hardware logic analyzers, raw telemetry oscilloscopes, and legacy silicon debug tooling.

## Components

### Buttons
- **Primary / Exploit Action**: Background `#FF5B6E`, text `#070B12`, 0px radius, uppercase `Space Mono` typography. Hover shifts background to `#FF7585`. Active compresses by 1px inward outline.
- **Secondary / Safety Verification**: Background transparent, 1px solid `#B7FF4A`, text `#B7FF4A`. Hover shifts background to `#B7FF4A` at 10% opacity.
- **Ghost / Utility**: Background `#0D1424`, 1px solid `#1E2D4A`, text `#8E9BAE`. Hover brings border to `#5B6B82` and text to `#FFFBE8`.

### Verdict Badges
All badges share a flat, rectangular structure, 0px radius, 1px solid border, with padding `0.25rem 0.5rem`:
- `EXPLOIT_SUCCEEDED`: Background `#FF5B6E` (12% opacity), border `#FF5B6E`, text `#FF5B6E`.
- `ATTEMPT_BLOCKED`: Background `#B7FF4A` (12% opacity), border `#B7FF4A`, text `#B7FF4A`.
- `ATTACK_NOT_TRIGGERED`: Background `#6B7280` (12% opacity), border `#6B7280`, text `#8E9BAE`.
- `TEST_ERROR`: Background `#FEE101` (12% opacity), border `#FEE101`, text `#FEE101`.

### Input Fields & Terminal Prompts
- Background `#0D1424`, 1px solid `#1E2D4A`, text `#FFFBE8`, placeholder `#5B6B82`.
- Focus state replaces the border with a sharp 1px solid `#B7FF4A` with zero outer shadow.
- Code & Prompt Injection fields feature an integrated left-hand diagnostic gutter displaying execution line index numbers in `#5B6B82`.

### Cards & Telemetry Containers
- Background `#0D1424`, delimited by 1px solid borders in `#1E2D4A`.
- Header bars are partitioned with a bottom border of 1px solid `#1E2D4A` and set in `#121B30`, featuring monospace section titles paired with running execution timestamps.

### Checkboxes & Binary Toggles
- Custom square markers (14px x 14px), 0px radius, 1px solid `#1E2D4A`.
- Checked state fills the box entirely with `#B7FF4A` or `#FF5B6E` (context-dependent) containing a centered 2px solid dark core `#070B12`.

### Specialized Telemetry Components
- **Trace Diff Viewer**: Split-pane horizontal container contrasting original agent prompt instructions against injected adversarial payloads. Injected mutations are framed by a 1px solid `#FF5B6E` outline.
- **Sandboxed Fund Monitor**: Compact tabular matrix rendering token balances, unauthorized transaction permits, and signature leaks using monospace numerals, right-aligned for systematic vertical scanning.